import { StreamingDemo } from '../try-it-now/screens/streaming-demo';

export default function StreamingDemoPage() {
  return <StreamingDemo />;
} 